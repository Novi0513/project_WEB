from flask import (
    Flask,
    url_for,
    request,
    render_template,
    redirect)

from data.discussion import Discussions

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


from flask_login import (LoginManager,
                         login_user,
                         login_required,
                         logout_user)
login_manager = LoginManager()
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)

from flask import make_response, jsonify

from flask_wtf import FlaskForm
from wtforms import (EmailField,
                     PasswordField,
                     BooleanField,
                     SubmitField,
                     StringField,
                     TextAreaField)
from wtforms.validators import DataRequired

from data.users import User

from hashlib import blake2b
import os
import json

from data import db_session, discussion_api


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class RegisterForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    password_again = PasswordField('Повторите пароль', validators=[DataRequired()])
    name = StringField('Имя пользователя', validators=[DataRequired()])
    about = TextAreaField("Немного о себе")
    submit = SubmitField('Создать аккаунт')


class SettingsForm(FlaskForm):
    email = EmailField('Изменить почту', validators=[DataRequired()])
    name = StringField('Изменить имя пользователя', validators=[DataRequired()])
    about = TextAreaField("Изменить информацию")
    submit = SubmitField('Принять')


class ProfileDiscussionsForm(FlaskForm):
    title = StringField('Заголовок', validators=[DataRequired()])
    content = TextAreaField("Текст Обсуждения")
    submit = SubmitField('Создать')


@app.route('/')
@app.route('/index')
def index():
    text = open('pages\Index.txt',
                "r",
                encoding="utf-8").readlines()
    with open("pages/persons_list.json", "rt", encoding="utf8") as f:
        persons = json.loads(f.read())
    return render_template('index.html',
                           text=text,
                           persons=persons)


@app.route('/Letov')
def letov():
    singer = "Егор Летов"
    image = f"{url_for('static', filename='img/Letov.jpg')}"
    alt = "здесь должна была быть картинка, но не нашлась"
    page = open('pages/persons/Letov.txt',
                "r",
                encoding="utf-8").readlines()
    return render_template('Letov_ex.html',
                           Singer=singer,
                           img=image,
                           alt=alt,
                           text=page)


@app.route('/Hammett')
def hammett():
    singer = "Кирк Ли Хэмметт"
    image = f"{url_for('static', filename='img/Kirk_Hammett.jpg')}"
    alt = "здесь должна была быть картинка, но не нашлась"
    page = open('pages/persons/Hammett.txt',
                "r",
                encoding="utf-8").readlines()
    return render_template('Letov_ex.html',
                           Singer=singer,
                           img=image,
                           alt=alt,
                           text=page)


@app.route('/Khoi')
def khoi():
    singer = "Юрий Хой"
    image = f"{url_for('static', filename='img/Khoi.jpg')}"
    alt = "здесь должна была быть картинка, но не нашлась"
    page = open('pages/persons/Khoi.txt',
                "r",
                encoding="utf-8").readlines()
    return render_template('Letov_ex.html',
                           Singer=singer,
                           img=image,
                           alt=alt,
                           text=page)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user:
            log_hash = blake2b(salt=bytes.fromhex(user.hashed_password[:32]))
            log_hash.update(str.encode(form.password.data))
            log_password = bytes.fromhex(user.hashed_password[:32]).hex() + log_hash.hexdigest()
            if user and log_password == user.hashed_password:
                login_user(user, remember=form.remember_me.data)
                return redirect(f"/profile/{user.name}")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html',
                           title='Авторизация',
                           form=form)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html',
                                   title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html',
                                   title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        password = str.encode(form.password.data)
        salt = os.urandom(blake2b.SALT_SIZE)
        hash0 = blake2b(salt=salt)
        hash0.update(password)
        hashed_password = salt.hex() + hash0.hexdigest()
        user.hashed_password = hashed_password
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('reg.html',
                           title='Регистрация',
                           form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/index")


@app.route('/profile/<username>', methods=['POST', 'GET'])
@login_required
def profile(username):
    if request.method == 'GET':
        return render_template('profile.html')
    elif request.method == 'POST':
        f = request.files['file']
        print(f.read())
        return "Форма отправлена"


@app.route('/profile/<username>/settings', methods=['POST', 'GET'])
@login_required
def profile_settings(username):
    form = SettingsForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.name == username).first()
        if form.name.data:
            user.name = form.name.data
        if form.email.data:
            user.email = form.email.data
        if form.about.data:
            user.about = form.about.data
        db_sess.commit()
        return redirect(f"/profile/{username}")
    return render_template('profile_settings.html',
                           form=form)


@app.route('/profile/<username>/discussions', methods=['POST', 'GET'])
@login_required
def profile_discussions(username):
    form = ProfileDiscussionsForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.name == username).first()
        discussion = Discussions(title=form.title.data, content=form.content.data)
        user.discussions.append(discussion)
        db_sess.commit()
        return redirect(f"/profile/{username}")
    return render_template('profile_discussions.html',
                           form=form)


@app.route('/discussions', methods=['POST', 'GET'])
def discussions():
    db_sess = db_session.create_session()
    discussion_list = db_sess.query(Discussions).filter()
    return render_template("discussions.html", discussions=discussion_list)

if __name__ == '__main__':
    @app.errorhandler(404)
    def not_found(error):
        return make_response(jsonify({'error': 'Not found'}), 404)


    @app.errorhandler(400)
    def bad_request(_):
        return make_response(jsonify({'error': 'Bad Request'}), 400)
    db_session.global_init("db/base.db")
    db_session.global_init("db/blogs.db")
    app.register_blueprint(discussion_api.blueprint)
    app.run(port=8000, host='127.0.0.1')