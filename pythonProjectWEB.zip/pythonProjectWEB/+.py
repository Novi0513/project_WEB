from requests import get

print(get('http://localhost:8000/api/discussion').json())
